import React, { useState } from 'react';
import axios from 'axios';

interface Four {
  id: number;
  data: number[];
}

const Szamnegy = () => {
  const [fours, setFours] = useState<Four[]>([]);
  const [num1, setNum1] = useState<number | ''>('');
  const [num2, setNum2] = useState<number | ''>('');
  const [num3, setNum3] = useState<number | ''>('');
  const [num4, setNum4] = useState<number | ''>('');
  const [fetchId, setFetchId] = useState<number | ''>('');
  const [fetchedData, setFetchedData] = useState<Four | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const addFour = async () => {
    if ([num1, num2, num3, num4].some((num) => num === '')) {
      setErrorMessage('Minden számot meg kell adni!');
      return;
    }

    const data = [num1, num2, num3, num4].map((num) => num as number);

    try {
      const response = await axios.post('http://localhost:3000/fours', { data });
      const newFour = response.data;
      setFours([...fours, newFour]);
      setNum1('');
      setNum2('');
      setNum3('');
      setNum4('');
      setErrorMessage(null);
    } catch (error) {
      setErrorMessage('Hiba történt a számnégyes hozzáadásakor!');
    }
  };

  const fetchAllFours = async () => {
    try {
      const response = await axios.get('http://localhost:3000/fours');
      setFours(response.data);
    } catch (error) {
      setErrorMessage('Hiba történt az adatok lekérésekor!');
    }
  };

  const fetchFourById = async () => {
    if (fetchId === '') {
      setErrorMessage('Adja meg az ID-t!');
      return;
    }

    try {
      const response = await axios.get(`http://localhost:3000/fours/${fetchId}`);
      setFetchedData(response.data);
      setErrorMessage(null);
    } catch (error) {
      setErrorMessage('A keresett számnégyes nem található!');
      setFetchedData(null);
    }
  };

  return (
    <div>
      <h1>Számnégyesek kezelése</h1>

      {/* Hibaüzenet */}
      {errorMessage && <div style={{ color: 'red' }}>{errorMessage}</div>}

      <h2>Új számnégyes hozzáadása</h2>
      <input
        type="number"
        value={num1}
        onChange={(e) => setNum1(Number(e.target.value))}
        placeholder="Szám 1"
      />
      <input
        type="number"
        value={num2}
        onChange={(e) => setNum2(Number(e.target.value))}
        placeholder="Szám 2"
      />
      <input
        type="number"
        value={num3}
        onChange={(e) => setNum3(Number(e.target.value))}
        placeholder="Szám 3"
      />
      <input
        type="number"
        value={num4}
        onChange={(e) => setNum4(Number(e.target.value))}
        placeholder="Szám 4"
      />
      <button onClick={addFour}>Hozzáadás</button>

      <h2>Számnégyesek lekérdezése</h2>
      <button onClick={fetchAllFours}>Összes számnégyes lekérése</button>

      <div>
        <h3>Összes számnégyes:</h3>
        {fours.length > 0 ? (
          fours.map((four) => (
            <p key={four.id}>
              ID: {four.id}, Adatok: {four.data.join(', ')}
            </p>
          ))
        ) : (
          <p>Nincsenek számnégyesek.</p>
        )}
      </div>

      <h2>Számnégyes lekérdezése ID alapján</h2>
      <input
        type="number"
        value={fetchId}
        onChange={(e) => setFetchId(Number(e.target.value))}
        placeholder="ID"
      />
      <button onClick={fetchFourById}>Lekérdezés</button>

      <div>
        {fetchedData && (
          <p>
            ID: {fetchedData.id}, Adatok: {fetchedData.data.join(', ')}
          </p>
        )}
        {!fetchedData && fetchId !== '' && <p>A keresett számnégyes nem található!</p>}
      </div>
    </div>
  );
};

export default Szamnegy;