import React, { useState } from 'react';
import '../style.css';

const Oldal = () => {
    const [a, setA] = useState(0);
    const [b, setB] = useState(0);
    const [c, setC] = useState(0);

    const [d, setD] = useState(0);
    const [e, setE] = useState(0);
    const [f, setF] = useState(0);

    const [g, setG] = useState(0);
    const [h, setH] = useState(0);
    const [i, setI] = useState(0);

    const APressed = () => {
        setA(a + 1);
        setB(b + 1);
        setD(d + 1);
        setE(e + 1);
    };

    const BPressed = () => {
        setB(b + 1);
        setC(c + 1);
        setE(e + 1);
        setF(f + 1);
    };

    const CPressed = () => {
        setD(d + 1);
        setE(e + 1);
        setG(g + 1);
        setH(h + 1);
    };

    const DPressed = () => {
        setE(e + 1);
        setF(f + 1);
        setH(h + 1);
        setI(i + 1);
    };

    const Nullaz=()=>{
        setA(0);
        setB(0);
        setD(0);
        setE(0);
        setB(0);
        setC(0);
        setE(0);
        setF(0);
        setD(0);
        setE(0);
        setG(0);
        setH(0);
        setE(0);
        setF(0);
        setH(0);
        setI(0);
    }

    const Tomb = () =>{
        alert(`[${a}; ${c}; ${g}; ${i}]`)
    }

    return (
        <>
            <body>
                <div className="container-1">
                    <button onClick={APressed}>A</button>
                    <button onClick={BPressed}>B</button>
                </div>
                <div className="container-3">
                    <div>{a}</div>
                    <div>{b}</div>
                    <div>{c}</div>
                </div>
                <div className="container-4">
                    <div>{d}</div>
                    <div>{e}</div>
                    <div>{f}</div>
                </div>
                <div className="container-5">
                    <div>{g}</div>
                    <div>{h}</div>
                    <div>{i}</div>
                </div>
                <div className="container-6">
                    <button onClick={CPressed}>C</button>
                    <button onClick={DPressed}>D</button>
                </div>
                <div className='container-7'>
                <button onClick={Nullaz}>Nullázás</button>
                </div>
                <div className='container-8'>
                <button onClick={Tomb}>Tömbkiirasa</button>
                </div>
            </body>
        </>
    );
};

export default Oldal;
