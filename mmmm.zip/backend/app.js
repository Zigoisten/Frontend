import express from 'express';
import bodyParser from 'body-parser';

const app = express();
const port = 3001;

app.use(bodyParser.json());

let fours = {};
let nextId = 1;

function isValidData(data) {
    return Array.isArray(data) && data.length === 4 && data.every(num => typeof num === 'number');
}

app.post('/fours', (req, res) => {
    const { data } = req.body;

    if (!isValidData(data)) {
        return res.status(400).json({ message: 'Invalid data' });
    }

    const id = nextId++;
    fours[id] = data;

    res.status(201).json({ id, data });
});

app.get('/fours', (req, res) => {
    const allFours = Object.entries(fours).map(([id, data]) => ({ id, data }));
    res.json(allFours);
});

app.get('/fours/:id', (req, res) => {
    const { id } = req.params;

    if (!fours[id]) {
        return res.status(404).json({ message: 'Not found' });
    }

    res.json({ id, data: fours[id] });
});

app.all('*', (req, res) => {
    res.status(404).json({ message: 'Not found' });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
